<?php
/**
 * The template for displaying Category pages
 *
 * Used to display archive-type pages for posts in a category.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Thebell_Theme
 * @since Thebell 1.0
 */

$thebell_opt = get_option( 'thebell_opt' );

get_header();

$thebell_bloglayout = 'nosidebar';
if(isset($thebell_opt['blog_layout']) && $thebell_opt['blog_layout']!=''){
	$thebell_bloglayout = $thebell_opt['blog_layout'];
}
if(isset($_GET['layout']) && $_GET['layout']!=''){
	$thebell_bloglayout = $_GET['layout'];
}
$thebell_blogsidebar = 'right';
if(isset($thebell_opt['sidebarblog_pos']) && $thebell_opt['sidebarblog_pos']!=''){
	$thebell_blogsidebar = $thebell_opt['sidebarblog_pos'];
}
if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
	$thebell_blogsidebar = $_GET['sidebar'];
}
switch($thebell_bloglayout) {
	case 'sidebar':
		$thebell_blogclass = 'blog-sidebar';
		$thebell_blogcolclass = 9;
		Thebell_Class::thebell_post_thumbnail_size('thebell-category-thumb');
		break;
	case 'largeimage':
		$thebell_blogclass = 'blog-large';
		$thebell_blogcolclass = 9;
		$thebell_postthumb = '';
		break;
	default:
		$thebell_blogclass = 'blog-nosidebar';
		$thebell_blogcolclass = 12;
		$thebell_blogsidebar = 'none';
		Thebell_Class::thebell_post_thumbnail_size('thebell-post-thumb');
}
?>
<div class="main-container">
	<div class="title-breadcrumb">
		<div class="container">
			<div class="title-breadcrumb-inner">
				<header class="entry-header">
					<h1 class="entry-title"><?php if(isset($thebell_opt)) { echo esc_html($thebell_opt['blog_header_text']); } else { esc_html_e('Blog', 'thebell');}  ?></h1>
				</header>  
				<?php Thebell_Class::thebell_breadcrumb(); ?>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			
			<?php if($thebell_blogsidebar=='left') : ?>
				<?php get_sidebar(); ?>
			<?php endif; ?>
			<div class="col-xs-12 <?php echo 'col-md-'.$thebell_blogcolclass; ?>">
			
				<div class="page-content blog-page <?php echo esc_attr($thebell_blogclass); if($thebell_blogsidebar=='left') {echo ' left-sidebar'; } if($thebell_blogsidebar=='right') {echo ' right-sidebar'; } ?>">
				
					<?php if ( have_posts() ) : ?>
						<header class="archive-header">
							<h1 class="archive-title"><?php printf( esc_html__( 'Category Archives: %s', 'thebell' ), '<span>' . single_cat_title( '', false ) . '</span>' ); ?></h1>

						<?php if ( category_description() ) : // Show an optional category description ?>
							<div class="archive-meta"><?php echo category_description(); ?></div>
						<?php endif; ?>
						</header><!-- .archive-header -->

						<?php
						/* Start the Loop */
						while ( have_posts() ) : the_post();

							/* Include the post format-specific template for the content. If you want to
							 * this in a child theme then include a file called called content-___.php
							 * (where ___ is the post format) and that will be used instead.
							 */
							get_template_part( 'content', get_post_format() );

						endwhile;
						?>
						
						<?php Thebell_Class::thebell_pagination(); ?>
						
					<?php else : ?>
						<?php get_template_part( 'content', 'none' ); ?>
					<?php endif; ?>
				</div>
			</div>
			<?php if( $thebell_blogsidebar=='right') : ?>
				<?php get_sidebar(); ?>
			<?php endif; ?>
		</div>
		
	</div>
	<!-- brand logo -->
	<?php 
		if(isset($thebell_opt['inner_brand']) && function_exists('thebell_brands_shortcode')){
			if($thebell_opt['inner_brand']){ ?>
				<div class="inner-brands">
					<div class="container">
						<?php if(isset($thebell_opt['inner_brand_title']) && $thebell_opt['inner_brand_title']!=''){ ?>
							<div class="title">
								<h3><?php echo esc_html( $thebell_opt['inner_brand_title'] ); ?></h3>
							</div>
						<?php } ?>
						<?php 
						if ( shortcode_exists( 'ourbrands' ) ) {
							echo do_shortcode('[ourbrands]');
						}
						?>
					</div>
				</div>
				
			<?php }
		}
	?>
	<!-- end brand logo -->  
</div>

<?php get_footer(); ?>