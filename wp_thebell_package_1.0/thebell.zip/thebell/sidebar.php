<?php
/**
 * The sidebar containing the main widget area
 *
 * If no active widgets are in the sidebar, hide it completely.
 *
 * @package WordPress
 * @subpackage Thebell_Theme
 * @since Thebell 1.0
 */

$thebell_opt = get_option( 'thebell_opt' );
 
$thebell_blogsidebar = 'right';
if(isset($thebell_opt['sidebarblog_pos']) && $thebell_opt['sidebarblog_pos']!=''){
	$thebell_blogsidebar = $thebell_opt['sidebarblog_pos'];
}
if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
	$thebell_blogsidebar = $_GET['sidebar'];
}
?>
<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
	<div id="secondary" class="col-xs-12 col-md-3 <?php if($thebell_blogsidebar=='left') { echo 'pull-left';} else { echo 'pull-right';}?>">
		<div class="sidebar-border <?php echo esc_attr($thebell_blogsidebar);?>">
			<?php dynamic_sidebar( 'sidebar-1' ); ?>
		</div>
	</div><!-- #secondary -->
<?php endif; ?>