<?php
/**
 * The template for displaying 404 pages (Not Found)
 *
 * @package WordPress
 * @subpackage Thebell_Theme
 * @since Thebell 1.0
 */

$thebell_opt = get_option( 'thebell_opt' );

get_header();

?>
	<div class="main-container error404">
		<div class="container">
			<div class="search-form-wrapper">
				<h1><?php esc_html_e( "404", 'thebell' ); ?></h1>
				<h2><?php esc_html_e( "OOPS! PAGE NOT BE FOUND", 'thebell' ); ?></h2>
				<p class="home-link"><?php esc_html_e( "Sorry but the page you are looking for does not exist, have been removed, name changed or is temporarity unavailable.", 'thebell' ); ?></p>
				<?php get_search_form(); ?>
				<a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_html_e( 'Back to home', 'thebell' ); ?>"><?php esc_html_e( 'Back to home page', 'thebell' ); ?></a>
			</div>
		</div>
		<!-- brand logo -->
		<?php 
			if(isset($thebell_opt['inner_brand']) && function_exists('thebell_brands_shortcode')){
				if($thebell_opt['inner_brand']){ ?>
					<div class="inner-brands">
						<div class="container">
							<?php if(isset($thebell_opt['inner_brand_title']) && $thebell_opt['inner_brand_title']!=''){ ?>
								<div class="title">
									<h3><?php echo esc_html( $thebell_opt['inner_brand_title'] ); ?></h3>
								</div>
							<?php } ?>
							<?php 
							if ( shortcode_exists( 'ourbrands' ) ) {
								echo do_shortcode('[ourbrands]');
							}
							?>
						</div>
					</div>
					
				<?php }
			}
		?>
		<!-- end brand logo -->  
	</div>
</div>
<?php get_footer(); ?>