<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * For example, it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Thebell_Theme
 * @since Thebell 1.0
 */

$thebell_opt = get_option( 'thebell_opt' );

get_header();

$thebell_bloglayout = 'sidebar';

if(isset($thebell_opt['blog_layout']) && $thebell_opt['blog_layout']!=''){
	$thebell_bloglayout = $thebell_opt['blog_layout'];
}
if(isset($_GET['layout']) && $_GET['layout']!=''){
	$thebell_bloglayout = $_GET['layout'];
}
$thebell_blogsidebar = 'right';
if(isset($thebell_opt['sidebarblog_pos']) && $thebell_opt['sidebarblog_pos']!=''){
	$thebell_blogsidebar = $thebell_opt['sidebarblog_pos'];
}
if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
	$thebell_blogsidebar = $_GET['sidebar'];
}

switch($thebell_bloglayout) {
	case 'sidebar':
		$thebell_blogclass = 'blog-sidebar';
		$thebell_blogcolclass = 9;
		Thebell_Class::thebell_post_thumbnail_size('thebell-category-thumb');
		break;
	case 'largeimage':
		$thebell_blogclass = 'blog-large';
		$thebell_blogcolclass = 9;
		Thebell_Class::thebell_post_thumbnail_size('thebell-category-thumb');
		break;
	case 'grid':
		$thebell_blogclass = 'grid';
		$thebell_blogcolclass = 9;
		Thebell_Class::thebell_post_thumbnail_size('thebell-category-thumb');
		break;
	default:
		$thebell_blogclass = 'blog-nosidebar';
		$thebell_blogcolclass = 12;
		$thebell_blogsidebar = 'none';
		Thebell_Class::thebell_post_thumbnail_size('thebell-post-thumb');
}
?>

<div class="main-container">
	<div class="title-breadcrumb">
		<div class="container">
			<div class="title-breadcrumb-inner">
				<header class="entry-header">
					<h1 class="entry-title"><?php if(isset($thebell_opt)) { echo esc_html($thebell_opt['blog_header_text']); } else { esc_html_e('Blog', 'thebell');}  ?></h1>
				</header>  
				<?php Thebell_Class::thebell_breadcrumb(); ?>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			
			<div class="col-xs-12 <?php echo 'col-md-'.$thebell_blogcolclass; ?> <?php if($thebell_blogsidebar=='left') { echo 'pull-right';} else { echo 'pull-left';}?>">
			
				<div class="page-content blog-page <?php echo esc_attr($thebell_blogclass); if($thebell_blogsidebar=='left') {echo ' left-sidebar'; } if($thebell_blogsidebar=='right') {echo ' right-sidebar'; } ?>">
					<?php if ( have_posts() ) : ?>

						<?php /* Start the Loop */ ?>
						<?php while ( have_posts() ) : the_post(); ?>
							
							<?php get_template_part( 'content', get_post_format() ); ?>
							
						<?php endwhile; ?>

						<?php Thebell_Class::thebell_pagination(); ?>
						
					<?php else : ?>

						<article id="post-0" class="post no-results not-found">

						<?php if ( current_user_can( 'edit_posts' ) ) :
							// Show a different message to a logged-in user who can add posts.
						?>
							<header class="entry-header">
								<h1 class="entry-title"><?php esc_html_e( 'No posts to display', 'thebell' ); ?></h1>
							</header>

							<div class="entry-content">
								<p><?php printf( wp_kses(__( 'Ready to publish your first post? <a href="%s">Get started here</a>.', 'thebell' ), array('a'=>array('href'=>array()))), admin_url( 'post-new.php' ) ); ?></p>
							</div><!-- .entry-content -->

						<?php else :
							// Show the default message to everyone else.
						?>
							<header class="entry-header">
								<h1 class="entry-title"><?php esc_html_e( 'Nothing Found', 'thebell' ); ?></h1>
							</header>

							<div class="entry-content">
								<p><?php esc_html_e( 'Apologies, but no results were found. Perhaps searching will help find a related post.', 'thebell' ); ?></p>
								<?php get_search_form(); ?>
							</div><!-- .entry-content -->
						<?php endif; // end current_user_can() check ?>

						</article><!-- #post-0 -->

					<?php endif; // end have_posts() check ?>
				</div>
				
			</div>
			
			<?php if($thebell_blogsidebar != 'none') {
				get_sidebar();
			} ?>
			
		</div>
	</div>
	<!-- brand logo -->
	<?php 
		if(isset($thebell_opt['inner_brand']) && function_exists('thebell_brands_shortcode')){
			if($thebell_opt['inner_brand']){ ?>
				<div class="inner-brands">
					<div class="container">
						<?php if(isset($thebell_opt['inner_brand_title']) && $thebell_opt['inner_brand_title']!=''){ ?>
							<div class="title">
								<h3><?php echo esc_html( $thebell_opt['inner_brand_title'] ); ?></h3>
							</div>
						<?php } ?>
						<?php 
						if ( shortcode_exists( 'ourbrands' ) ) {
							echo do_shortcode('[ourbrands]');
						}
						?>
					</div>
				</div>
				
			<?php }
		}
	?>
	<!-- end brand logo --> 
</div>
<?php get_footer(); ?>