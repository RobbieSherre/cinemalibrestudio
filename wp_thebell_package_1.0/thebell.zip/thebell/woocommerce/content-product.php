<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woothemes.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product, $woocommerce_loop;

$thebell_opt = get_option( 'thebell_opt' );

$thebell_viewmode = Thebell_Class::thebell_show_view_mode();
$thebell_productsfound = Thebell_Class::thebell_shortcode_products_count();

// Ensure visibility
if ( ! $product || ! $product->is_visible() )
	return;

// Extra post classes
$classes = array();

$count   = $product->get_rating_count();

$colwidth = 3;

if($woocommerce_loop['columns'] > 0){
	$colwidth = round(12/$woocommerce_loop['columns']);
}

$classes[] = ' item-col col-xs-12 col-full-hd col-sm-'.$colwidth ;?>

<?php if ( ( 0 == ( $woocommerce_loop['loop'] ) % 2 ) && ( $woocommerce_loop['columns'] == 2 ) ) {
	echo '<div class="group">';
} ?>
<?php if ( ( 0 == ( $woocommerce_loop['loop'] ) % 3 ) && ( $woocommerce_loop['columns'] == 3 ) ) {
	echo '<div class="group">';
} ?>

<div <?php post_class( $classes ); ?>>
	<div class="product-wrapper">
		<div class="gridview">
			<div class="list-col4">
				<div class="product-image">
					<?php do_action( 'woocommerce_before_shop_loop_item' ); ?>
						<?php 
						echo wp_kses($product->get_image('shop_catalog', array('class'=>'primary_image')), array(
							'a'=>array(
								'href'=>array(),
								'title'=>array(),
								'class'=>array(),
							),
							'img'=>array(
								'src'=>array(),
								'height'=>array(),
								'width'=>array(),
								'class'=>array(),
								'alt'=>array(),
							)
						));
						
						if(isset($thebell_opt['second_image'])){
							if($thebell_opt['second_image']){
								$attachment_ids = $product->get_gallery_attachment_ids();
								if ( $attachment_ids ) {
									echo wp_get_attachment_image( $attachment_ids[0], apply_filters( 'single_product_small_thumbnail_size', 'shop_catalog' ), false, array('class'=>'secondary_image') );
								}
							}
						}
						?>
					<?php do_action( 'woocommerce_after_shop_loop_item' ); ?>
					<!-- end image link -->
					<div class="add-to-wishlist"> 
						<?php if ( class_exists( 'YITH_WCWL' ) ) {
							echo preg_replace("/<img[^>]+\>/i", " ", do_shortcode('[yith_wcwl_add_to_wishlist]'));
						} ?>
					</div>
					<!-- end add-to-wishlist -->
					<div class="actions actions-gridview clearfix"> 
						<?php if ( isset($thebell_opt['quickview']) && $thebell_opt['quickview'] ) { ?>
							<div class="quickviewbtn">
								<a class="detail-link quickview" data-quick-id="<?php the_ID();?>" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo esc_html($thebell_opt['detail_link_text']);?></a>
							</div>
						<?php } ?>
						<!-- end quickview -->
					</div>
					<!-- end actions -->
				</div>
				<!-- end product image -->
				
			</div>
			<div class="list-col8">
				<?php 
					echo $product->get_categories( '<span class="separator">,</span>' , '<div class="product-category">' . esc_html(' ', get_the_terms( $post->ID, 'product_cat' ) , 'thebell' ) . ' ', ' </div>' ); 
				?>
				<!-- end product-category -->
				<h2 class="product-name">
					<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
				</h2>
				<!-- end product-name -->
				<div class="product-price"><?php echo ''.$product->get_price_html(); ?></div>
				<!-- end product-price -->
			</div>
		</div>
		<!-- end gridview -->
		<div class="listview">
			<div class="list-col4 <?php if($thebell_viewmode=='list-view'){ echo ' col-xs-12 col-sm-4';} ?>">
				<div class="product-image">
					<?php do_action( 'woocommerce_before_shop_loop_item' ); ?>
						<?php 
						echo wp_kses($product->get_image('shop_catalog', array('class'=>'primary_image')), array(
							'a'=>array(
								'href'=>array(),
								'title'=>array(),
								'class'=>array(),
							),
							'img'=>array(
								'src'=>array(),
								'height'=>array(),
								'width'=>array(),
								'class'=>array(),
								'alt'=>array(),
							)
						));
						
						if(isset($thebell_opt['second_image'])){
							if($thebell_opt['second_image']){
								$attachment_ids = $product->get_gallery_attachment_ids();
								if ( $attachment_ids ) {
									echo wp_get_attachment_image( $attachment_ids[0], apply_filters( 'single_product_small_thumbnail_size', 'shop_catalog' ), false, array('class'=>'secondary_image') );
								}
							}
						}
						?>
					<?php do_action( 'woocommerce_after_shop_loop_item' ); ?>
					<!-- end image link -->
					<div class="add-to-wishlist"> 
						<?php if ( class_exists( 'YITH_WCWL' ) ) {
							echo preg_replace("/<img[^>]+\>/i", " ", do_shortcode('[yith_wcwl_add_to_wishlist]'));
						} ?>
					</div> 
					<!-- end add-to-wishlist -->
				</div>
				<!-- end product image -->
			</div>
			<div class="list-col8 <?php if($thebell_viewmode=='list-view'){ echo ' col-xs-12 col-sm-8';} ?>">
				<?php 
					echo $product->get_categories( '<span class="separator">,</span>' , '<div class="product-category">' . esc_html(' ', get_the_terms( $post->ID, 'product_cat' ) , 'thebell' ) . ' ', ' </div>' ); 
				?>
				<!-- end product-category -->
				<h2 class="product-name">
					<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
				</h2>
				<!-- end product-name -->
				<div class="product-price"><?php echo ''.$product->get_price_html(); ?></div>
				<!-- end product-price -->
				<div class="product-desc"><?php the_excerpt(); ?></div>
				<!-- end product-desc -->
				<div class="actions actions-listview"> 
					<div class="add-to-cart">
						<?php echo do_shortcode('[add_to_cart id="'.$product->id.'"]') ?>
					</div>
					<!-- end add-to-cart -->
				</div>
				<!-- end actions -->
			</div>
		</div>
		<!-- end listview -->
	</div>
</div>
<?php if ( ( ( 0 == $woocommerce_loop['loop'] % 2 || $thebell_productsfound == $woocommerce_loop['loop'] ) && $woocommerce_loop['columns'] == 2 )  ) { /* for odd case: $thebell_productsfound == $woocommerce_loop['loop'] */
	echo '</div>';
} ?>
<?php if ( ( ( 0 == $woocommerce_loop['loop'] % 3 || $thebell_productsfound == $woocommerce_loop['loop'] ) && $woocommerce_loop['columns'] == 3 )  ) { /* for odd case: $thebell_productsfound == $woocommerce_loop['loop'] */
	echo '</div>';
} ?>