<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Thebell_Theme
 * @since Thebell 1.0
 */
$thebell_opt = get_option( 'thebell_opt' );

get_header();
?>
<div class="main-container default-page">
	<div class="title-breadcrumb">
		<div class="container"> 
			<?php Thebell_Class::thebell_breadcrumb(); ?> 
			<header class="entry-header">
				<h1 class="entry-title"><?php the_title(); ?></h1>
			</header> 
		</div>
	</div>
	<div class="clearfix"></div>
	<div class="container">
		
		<div class="row"> 
			<?php
			$customsidebar = get_post_meta( $post->ID, '_thebell_custom_sidebar', true );
			$customsidebar_pos = get_post_meta( $post->ID, '_thebell_custom_sidebar_pos', true );

			if($customsidebar != ''){
				if($customsidebar_pos == 'left' && is_active_sidebar( $customsidebar ) ) {
					echo '<div id="secondary" class="col-xs-12 col-md-3">';
						dynamic_sidebar( $customsidebar );
					echo '</div>';
				} 
			} else {
				if( $thebell_opt['sidebarse_pos']=='left'  || !isset($thebell_opt['sidebarse_pos']) ) {
					get_sidebar('page');
				}
			} ?>
			<div class="col-xs-12 <?php if ( $customsidebar!='' || is_active_sidebar( 'sidebar-page' ) ) : ?>col-md-9<?php endif; ?>">
				<div class="page-content default-page">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part( 'content', 'page' ); ?>
						<?php comments_template( '', true ); ?>
					<?php endwhile; // end of the loop. ?>
				</div>
			</div>
			<?php
			if($customsidebar != ''){
				if($customsidebar_pos == 'right' && is_active_sidebar( $customsidebar ) ) {
					echo '<div id="secondary" class="col-xs-12 col-md-3">';
						dynamic_sidebar( $customsidebar );
					echo '</div>';
				} 
			} else {
				if( $thebell_opt['sidebarse_pos']=='right' ) {
					get_sidebar('page');
				}
			} ?>
		</div>
	</div> 
	<!-- brand logo -->
	<?php 
		if(isset($thebell_opt['inner_brand']) && function_exists('thebell_brands_shortcode')){
			if($thebell_opt['inner_brand']){ ?>
				<div class="inner-brands">
					<div class="container">
						<?php if(isset($thebell_opt['inner_brand_title']) && $thebell_opt['inner_brand_title']!=''){ ?>
							<div class="title">
								<h3><?php echo esc_html( $thebell_opt['inner_brand_title'] ); ?></h3>
							</div>
						<?php } ?>
						<?php 
						if ( shortcode_exists( 'ourbrands' ) ) {
							echo do_shortcode('[ourbrands]');
						}
						?>
					</div>
				</div>
				
			<?php }
		}
	?>
	<!-- end brand logo --> 
</div>
<?php get_footer(); ?>