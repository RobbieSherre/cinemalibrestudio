		var thebell_brandnumber = 6,
			thebell_brandscrollnumber = 2,
			thebell_brandpause = 3000,
			thebell_brandanimate = 2000;
		var thebell_brandscroll = false;
							thebell_brandscroll = true;
					var thebell_categoriesnumber = 6,
			thebell_categoriesscrollnumber = 2,
			thebell_categoriespause = 3000,
			thebell_categoriesanimate = 700;
		var thebell_categoriesscroll = 'false';
					var thebell_blogpause = 3000,
			thebell_bloganimate = 2000;
		var thebell_blogscroll = false;
							thebell_blogscroll = false;
					var thebell_testipause = 3000,
			thebell_testianimate = 2000;
		var thebell_testiscroll = false;
							thebell_testiscroll = false;
					var thebell_catenumber = 6,
			thebell_catescrollnumber = 2,
			thebell_catepause = 3000,
			thebell_cateanimate = 700;
		var thebell_catescroll = false;
					var thebell_menu_number = 8;
		var thebell_sticky_header = false;
							thebell_sticky_header = true;
					jQuery(document).ready(function(){
			jQuery("#ws").focus(function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("");
				}
			});
			jQuery("#ws").focusout(function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("");
				}
			});
			jQuery("#wsearchsubmit").click(function(){
				if(jQuery("#ws").val()=="" || jQuery("#ws").val()==""){
					jQuery("#ws").focus();
					return false;
				}
			});
			jQuery("#search_input").focus(function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("");
				}
			});
			jQuery("#search_input").focusout(function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("");
				}
			});
			jQuery("#blogsearchsubmit").click(function(){
				if(jQuery("#search_input").val()=="" || jQuery("#search_input").val()==""){
					jQuery("#search_input").focus();
					return false;
				}
			});
		});
		